#' Get WUR styled colour palettes
#'
#' Get any of the palettes that are predefined based on the WUR
#' style guide.
#'
#' Get any of the palettes that are predefined based on the WUR
#' style guide.
#' @param name Specify the name of a WUR palette. Should be
#' one of [wur_palette_names()]. See also [show_wur_palettes()].
#' @returns `brewur` returns a `vector` of colours for the selected
#' palette
#' @examples
#' \dontrun{
#' brewur()        # returns the default compiled palette
#' brewur("wur_o") # returns the palette for on-line materials
#'
#' show_wur_palettes() # show available palettes
#'
#' wur_palette_names() # list all available palettes
#' }
#' @author Pepijn de Vries
#' @name brewur
#' @rdname palette
#' @export
brewur <- function(
    name =
      c("wur_c", "wur_p", "wur_s", "wur_o", "extra",
        paste0("wur_l", letters[1:6]),
        sort(paste0("wur_l2", apply(expand.grid(c("a", "b", "e"),
                                                c("c", "d", "f")), 1, paste0, collapse = ""))))) {
  name <- match.arg(name)
  cols <- ggthemewur::wur_colours
  sel <- unlist(lapply(lapply(strsplit(cols$sets, "\\|"), `==`, name), any))
  if (all(!sel)) {
    if (startsWith(name, "wur_l2")) {
      col1 <- brewur()[c(1:5, 7)][match(substr(name, 7, 7), letters)]
      col2 <- brewur()[c(1:5, 7)][match(substr(name, 8, 8), letters)]
      scales::gradient_n_pal(c(col1, grDevices::grey(.95), col2))(seq(0, 1, length.out = 11))
    } else {
      col <- brewur()[c(1:5, 7)][match(substr(name, 6, 6), letters)]
      rev(scales::gradient_n_pal(c(col, .low_col(col)))(seq(0, 1, length.out = 9)))
    }
  } else {
    cols$rgb[sel]
  }
}

.low_col <- function(col, fact = 0.95) {
  col_low <- grDevices::col2rgb(col)/255
  # modify colour to 90% lightness:
  const <- (3*fact - sum(col_low))/(3 - sum(col_low))
  do.call(grDevices::rgb, as.list(col_low + const*(1 - col_low)))
}

#' @returns `show_wur_palettes` returns a `ggplot` object. When
#' evaluated it will display all available WUR palettes on the
#' active graphical device.
#' @name show_wur_palettes
#' @rdname palette
#' @export
show_wur_palettes <- function() {
  .data <- NULL

  palettes <- wur_palette_names()
  palettes <- as.data.frame(
    do.call(rbind,mapply(cbind, palettes, lapply(lapply(palettes, brewur), rev))))
  names(palettes)  <- c("palette", "rgb")
  palettes$palette <- factor(palettes$palette, unique(palettes$palette))
  palettes$idx     <- sprintf("%03i", 1:nrow(palettes))
  palettes$size    <- 1
  palettes$facet   <- 2
  palettes$facet[grepl("_l", palettes$palette)] <- 1
  palettes$facet[grepl("_l2", palettes$palette)] <- 3

  ggplot2::ggplot(palettes, ggplot2::aes_string(y = "palette", x = "size", fill = "idx")) +
    ggplot2::facet_grid(rows = ggplot2::vars(.data$facet), scales = "free", space = "free") +
    ggplot2::geom_col(col = "lightgrey", lwd = 0.25) +
    ggplot2::theme_minimal() +
    ggplot2::theme(text              = ggplot2::element_text(family = "verdana"),
                   panel.grid        = ggplot2::element_blank(),
                   strip.background  = ggplot2::element_blank(),
                   strip.text        = ggplot2::element_blank()) +
    ggplot2::guides(x = ggplot2::guide_none(), fill = ggplot2::guide_none()) +
    ggplot2::scale_y_discrete(limits = rev) +
    ggplot2::labs(x = NULL) +
    ggplot2::scale_fill_manual(values = structure(palettes$rgb, names = palettes$idx))
}

#' @returns `wur_palette_names` returns a `vector` of all available
#' WUR palette names
#' @name wur_palette_names
#' @rdname palette
#' @export
wur_palette_names <- function(){
  eval(as.list(args(brewur))$name)
}
