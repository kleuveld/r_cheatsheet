.onAttach <- function(libname, pkgname){
  if (!"Verdana" %in% extrafont::fonts()) {
    extrafont::ttf_import(path = system.file(package = "ggthemewur", "fonts"))
  }
  extrafont::loadfonts()
}
