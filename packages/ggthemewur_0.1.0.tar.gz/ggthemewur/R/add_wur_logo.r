#' Add WUR logo to base plot
#'
#' Simple function to add a WUR logo to a base plot.
#'
#' Simple function to add a WUR logo to a base plot.
#' @param x,y relative position (between 0 and 1) to place the logo
#' @inheritParams annotate_wur_logo
#' @returns None
#' @family logo-related-pages
#' @examples
#' plot(1:10)
#' add_wur_logo()
#' @author Pepijn de Vries
#' @export
add_wur_logo <- function(logo = c("wur", "wur_b", "wur_w"),
                         x = 0.1, y = 0.1, size = 0.2, alpha = 1) {
  logo <- .get_logo(match.arg(logo))
  vp   <- grid::viewport(x, y, size, size)
  gp   <- grid::gpar(alpha = alpha)
  logo <- grid::editGrob(logo, vp = vp, gp = gp)
  grid::grid.draw(logo)
}

.get_logo <- function(logo) {
  switch(logo,
         wur   = ggthemewur::wur_logo,
         wur_b = ggthemewur::wur_logo_b,
         wur_w = ggthemewur::wur_logo_w)
}

#' The WUR logo
#'
#' A grob tree object containing the WUR logo
#'
#' Easiest to apply by calling [annotate_wur_logo()] for `ggplot`s or
#' [add_wur_logo()] for base plots.
#'
#' @format wur_logo: a grob tree object ([grid::grob()])
#' containing the WUR logo
#' @format wur_logo_b: a grob tree object ([grid::gTree()])
#' containing the WUR logo in black
#' @format wur_logo_w: a grob tree object ([grid::gTree()])
#' containing the WUR logo in white
#' @docType data
#' @examples
#' data("wur_logo")
#' data("wur_logo_b")
#' data("wur_logo_w")
#' @family logo-related-pages
#' @name wur_logo
#' @rdname wur_logo
NULL

#' @format wur_logo_b
#' @docType data
#' @name wur_logo_b
#' @rdname wur_logo
NULL

#' @format wur_logo_w
#' @docType data
#' @name wur_logo_w
#' @rdname wur_logo
NULL
