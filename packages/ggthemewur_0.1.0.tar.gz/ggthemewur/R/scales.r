#' Continuous, binned and discrete colour scales
#'
#' Continuous, binned and discrete colour scales based on WUR
#' styled palettes.
#'
#' Continuous, binned and discrete colour scales based on WUR
#' styled palettes [brewur()]. These are counterpart for the
#' `ggplot` scales and can be used to decorate your plot with WUR
#' styled colours.
#' @param palette A palette name to be used in the scale. Should be
#' one of [wur_palette_names()]. See also [show_wur_palettes()].
#' @param direction A `numeric` value specifying the palette's direction
#' 1 for forwards and -1 for backwards.
#' @param ... passed onto the underpinning `scale_*` functions:
#' [ggplot2::scale_fill_discrete()], [ggplot2::scale_fill_continuous()],
#' [ggplot2::scale_fill_binned()], [ggplot2::scale_colour_discrete()],
#' [ggplot2::scale_colour_continuous()], and
#' [ggplot2::scale_colour_binned()]
#' @returns Returns a [ggplot2::Scale] class object which can be added to
#' a `ggplot`.
#' @examples
#' library(ggplot2)
#'
#' ggplot(mpg, aes(x = class, group = fl, fill = fl)) +
#'   geom_bar() + theme_wur() +
#'   scale_fill_wur_discrete()
#'
#' plot <-
#'   ggplot(mpg, aes(y = fl, x = class, colour = displ)) +
#'   geom_point() + theme_wur()
#'
#' plot + scale_colour_wur_continuous("wur_lf")
#' plot + scale_colour_wur_binned("wur_lf")
#' @author Pepijn de Vries
#' @include brewur.r
#' @export
#' @name scale_colour_wur_discrete
#' @rdname scale
scale_colour_wur_discrete <- function(palette = "wur_c", direction = 1, ...) {
  fun <- if (direction < 0) rev else I
  ggplot2::scale_colour_manual(values = fun(brewur(palette)), ...)
}

#' @name scale_color_wur_discrete
#' @rdname scale
#' @export
scale_color_wur_discrete <- function(palette = "wur_c", direction = 1, ...) {
  scale_colour_wur_discrete(palette, direction, ...)
}

#' @name scale_fill_wur_discrete
#' @rdname scale
#' @export
scale_fill_wur_discrete <- function(palette = "wur_c", direction = 1, ...) {
  fun <- if (direction < 0) rev else I
  ggplot2::scale_fill_manual(values = fun(brewur(palette)), ...)
}

#' @name scale_colour_wur_continuous
#' @rdname scale
#' @export
scale_colour_wur_continuous <- function(palette = "wur_la", direction = 1, ...) {
  fun <- if (direction < 0) rev else I
  ggplot2::scale_colour_gradientn(..., colours = fun(brewur(palette)))
}

#' @name scale_color_wur_continuous
#' @rdname scale
#' @export
scale_color_wur_continuous <- function(palette = "wur_la", direction = 1, ...) {
  scale_colour_wur_continuous(palette, direction, ...)
}

#' @name scale_fill_wur_continuous
#' @rdname scale
#' @export
scale_fill_wur_continuous <- function(palette = "wur_la", direction = 1, ...) {
  fun <- if (direction < 0) rev else I
  ggplot2::scale_fill_gradientn(..., colours = fun(brewur(palette)))
}

#' @name scale_colour_wur_binned
#' @rdname scale
#' @export
scale_colour_wur_binned <- function(palette = "wur_la", direction = 1, ...) {
  fun <- if (direction < 0) rev else I
  ggplot2::scale_colour_steps(..., low = fun(brewur(palette)))
}

#' @name scale_color_wur_binned
#' @rdname scale
#' @export
scale_color_wur_binned <- function(palette = "wur_la", direction = 1, ...) {
  scale_colour_wur_binned(palette, direction, ...)
}

#' @name scale_fill_wur_binned
#' @rdname scale
#' @export
scale_fill_wur_binned <- function(palette = "wur_la", direction = 1, ...) {
  fun <- if (direction < 0) rev else I
  ggplot2::scale_fill_steps(..., low = fun(brewur(palette)))
}
