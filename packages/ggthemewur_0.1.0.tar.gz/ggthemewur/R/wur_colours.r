#' Colours from the WUR style guide
#'
#' A `data.frame` with colours defined in the WUR style guide.
#'
#' It's best to obtain colours by calling [brewur()].
#' @format A `data.frame` containing colour information based on information
#' from the [style guide](https://brandportal.wur.nl/Styleguide/huisstijl).
#' @name wur_colours
#' @examples
#' data("wur_colours")
#' @docType data
NULL
