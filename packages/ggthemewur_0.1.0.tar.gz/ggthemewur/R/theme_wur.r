#' A WUR styled ggplot theme
#'
#' A WUR styled theme which controls all non-data display of a `ggplot`.
#' use [ggplot2::theme()] if you wish to further tweak the appearance.
#'
#' A WUR styled theme which controls all non-data display of a `ggplot`.
#' use [ggplot2::theme()] if you wish to further tweak the appearance.
#' @param ... arguments passed on to [ggplot2::theme()]
#' @returns A [ggplot2::theme()] object that can be added to a ggplot.
#' @examples
#' library(ggplot2)
#'
#' ggplot(mpg, aes(x = displ)) +
#'   geom_histogram(binwidth = 0.5, fill = brewur()[[1]]) +
#'   theme_wur()
#'
#' ggplot(aggregate(fl ~ class + displ, mpg, length),
#'        aes(y = fl, x = class, group = displ, fill = displ)) +
#'   geom_col() +
#'   theme_wur() +
#'   scale_fill_wur_continuous()
#' @author Pepijn de Vries
#' @export
theme_wur <- function(...) {
  cols <- brewur()
  ggplot2::theme(
    line             = ggplot2::element_line(colour = cols[5]),
    text             = ggplot2::element_text(family = "Verdana"),
    panel.background = ggplot2::element_rect(fill = "transparent", colour = cols[5]),
    panel.grid.minor = ggplot2::element_line("transparent"),
    panel.grid.major = ggplot2::element_line(
      colour = grDevices::adjustcolor(cols[2], alpha.f = 0.1)),
    strip.background = ggplot2::element_rect(fill = cols[3], colour = cols[5]),
    legend.key       = ggplot2::element_rect(fill = "transparent"),
    axis.line        = ggplot2::element_line(colour = cols[5]),
    axis.ticks       = ggplot2::element_line(colour = cols[5]),
    ...)
}
