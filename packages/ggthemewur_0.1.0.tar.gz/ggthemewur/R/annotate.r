#' Add WUR logo to ggplot
#'
#' Add a layer with WUR logo to a [ggplot2::ggplot()].
#'
#' Add a layer with WUR logo to a [ggplot2::ggplot()].
#' @param logo A string indicating which logo to depict: `"wur"` = colour logo;
#' `"wur_b"` = black logo; `"wur_w"` = white logo.
#' @param x,y Coordinates where to place the logo. Use `Inf` and `-Inf` to
#' place it at the edges of the plotting area.
#' @param just A `vector` of two values to specify the horizontal and
#' vertical justification (scaled between 0 and 1).
#' @param size scaling factor for sizing the logo
#' @param alpha Opacity of the logo (scaled between 0 and 1)
#' @param ... Arguments passed onto [ggplot2::layer()]
#' @family logo-related-pages
#' @returns A [ggplot2::layer()] object which can be added to a `ggplot`
#' @examples
#' library(ggplot2)
#'
#' ggplot(mpg, aes(x = displ)) +
#'   geom_histogram(binwidth = 0.5, fill = brewur()[[5]]) +
#'   theme_wur() +
#'   annotate_wur_logo(x = Inf, y = Inf, just = c(2.4, 1))
#' @author Pepijn de Vries
#' @include add_wur_logo.r
#' @export
annotate_wur_logo <- function(logo = c("wur", "wur_b", "wur_w"),
                              x = -Inf, y = Inf, just = c(0, 1),
                              size = .2, alpha = 1, ...) {

  logo <- match.arg(logo)

  GeomLogo <- ggplot2::GeomCustomAnn
  GeomLogo$draw_panel <- function (data, panel_params, coord,
                                   grob, x, y, size, just, alpha) {
    if (!inherits(coord, "CoordCartesian"))
      stop("annotation_wur_logo only works with coord_cartesian")

    grob <- .get_logo(logo)
    cr <- coord$range(panel_params)
    h  <- diff(cr$y)
    w  <- diff(cr$x)

    x[is.infinite(x) & x < 0] <- cr$x[[1]]
    x[is.infinite(x) & x > 0] <- cr$x[[2]]
    y[is.infinite(y) & y < 0] <- cr$y[[1]]
    y[is.infinite(y) & y > 0] <- cr$y[[2]]

    corners <- data.frame(x = c(x, x + w*size), y = c(y, y + h*size))
    data <- coord$transform(corners, panel_params)
    x_rng <- range(data$x, na.rm = TRUE)
    y_rng <- range(data$y, na.rm = TRUE)

    gp <- grid::gpar(alpha = alpha)
    vp <- grid::viewport(
      x     = min(x_rng),  y      = min(y_rng),
      width = diff(x_rng), height = diff(y_rng), just = just)
    grid::editGrob(grob, vp = vp, gp = gp)
  }

  ggplot2::layer(
    data = data.frame(x = NA),
    stat = ggplot2::StatIdentity, position = ggplot2::PositionIdentity,
    geom = GeomLogo, inherit.aes = FALSE,
    params = list(grob = logo, x = x, y = y, size = size, just = just,
                  alpha = alpha),
    ...
  )
}
