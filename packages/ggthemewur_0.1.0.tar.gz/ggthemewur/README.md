
## Overview

<img src="man/figures/logo.png" align="right" alt = "logo" />

`ggthemewur` is a tool that allows you to create a `ggplot` conform the
WUR brand style guide. It will only take one or two lines of extra code.

The package contains:

-   WUR logos (provided as Grid Graphical Objects aka `grid::grob`)
-   WUR brand colour palettes
-   WUR brand `ggplot2` theme including font and colour schemes.
-   WUR brand styled `ggplot2`-`colour` and -`fill` scales

Jump to:

-   [Installation](#installation)
-   [Usage: palettes](#the-palettes)
-   [Usage: theme](#the-theme)
-   [Usage: scales](#the-scales)
-   [Usage: logo](#the-logo)
-   [A note](#a-note)
-   [FAQ](#faq)
-   [Resources](#resources)

## Installation

Download the tarball (`tar.gz`) file of package from the [wiki
page](https://git.wur.nl/wmrkdown/ggthemewur/-/wikis/Download-ggthemewur)
and install from the `R` command line using `install.packages`.

### System requirements

The package was successfully tested on Windows and Linux.

## Usage

### The palettes

Start by loading the required packages (and making en example data set
available):

``` r
library(ggplot2)
library(ggthemewur)
data("mpg")
```

The package comes prepared with several build-in palettes. For an
overview call:

``` r
show_wur_palettes()
```

![](man/figures/README-wur-palettes-1.svg)<!-- -->

The palette names listed above can be used in custom scale functions
provided by the package.

Note that palette names starting with `"wur_l"` are palettes with a
gradient of luminescence values, which can be used in continuous scales.
`"wur_p"`is a set of colours based on the *primary* colours specified in
the WUR brand style guide. `"wur_s"` are *secondary* colours. `"wur_o"`
are colours used in *on-line* materials (website/intranet). `"extra"`
are supporting colours that can be used.

`"wur_c"` is a *compiled* set of colours of contrasting colours based on
the primary and secondary colours. It is used by default in discrete
scales in this package.

To obtain any of the palettes its best to call the function `brewur()`
(a nod to `RColorBrewer`’s `brewer.pal()`) and provide the desired
palette name.

### The theme

The WUR theme (`theme_wur()`) is simply added with the `+` operator to a
ggplot. It will automatically apply the WUR colour scheme and font to
the plot framework. An exception are the data related elements (shapes,
rectangles, lines, etc.), which are not controlled by the theme. Set
those colours (`fill` and `col`) manually or add one of the WUR
[scales](#the-scales). Examples of the WUR theme are provided in the
sections below.

### The scales

As the theme only handles non data aspects of the plot, colour scales
can be used to decorate those elements using `ggplot` aesthetics. The
package provides scales for both `fill` and `colour` aesthetics. For
those aesthetics we provide discrete, continuous and binned scales. Some
of these are demonstrated below.

``` r
ggplot(mpg, aes(x = class, group = fl, fill = fl)) +
  geom_bar() +
  theme_wur() +
  scale_fill_wur_discrete()
```

![](man/figures/README-wur-scale-discrete-1.svg)<!-- -->

``` r
ggplot(mpg, aes(x = cty, y = displ, group = fl, col = fl)) +
  geom_point() +
  facet_wrap(~drv) +
  theme_wur() +
  scale_colour_wur_discrete()
```

![](man/figures/README-wur-scale-discrete-continuous1-1.svg)<!-- -->

``` r
ggplot(aggregate(fl ~ class + displ, mpg, length),
       aes(y = fl, x = class, group = displ, fill = displ)) +
  geom_col() +
  theme_wur() +
  scale_fill_wur_continuous()
```

![](man/figures/README-wur-scale-discrete-continuous2-1.svg)<!-- -->

### The logo

The logo can simply be added with one line of code. You can tweak its
positioning and opacity with the function’s arguments.

``` r
ggplot(mpg, aes(x = class)) +
  geom_bar(fill = brewur()[[1]]) +
  theme_wur() +
  annotate_wur_logo()
```

![](man/figures/README-wur-logo-1.svg)<!-- -->

## A note

Whether the WUR theme and palettes are nice is a matter of taste and
open for debate. I’m not going to answer that question here. I’ve simply
taken the WUR style guide as a status quo and implemented it in the
present package.

From a data visualiser’s perspective there are usually much better
alternatives. For colour palettes one could consider using
[viridis](https://cran.r-project.org/package=viridis) or
[RColorBrewer](https://cran.r-project.org/package=RColorBrewer). Those
packages offer colour palettes that provide high contrasting colours and
also take colour-blindness into account.

In short: use this package only when branding is important.

## FAQ

-   **Q**: Can I apply the WUR theme to ‘base’ and ‘lattice’ plots too?
    -   **A**: `theme_wur()` cannot be applied to plot objects other
        than `ggplot`. However, the palettes provided in this package
        can be used in any plot type. The same goes for the WUR logo.
-   **Q**: I have more items in my discrete scale than there are colours
    in the palette. What should I do?
    -   **A**: You have several options:
        -   Reduce the number of items in your scale (recommended)
        -   Add custom colours to the palette yourself and break with
            the style guide.
        -   Use a different palette altogether.
-   **Q**: Should I use the WUR theme in scientific manuscripts?
    -   **A**: No, this theme is only meant for branding and is not
        optimised for visualising scientific data (see also note above).
-   **Q**: What is the meaning of life, the universe, and everything?
    -   **A**: 42.

## Resources

<https://brandportal.wur.nl/Styleguide/huisstijl>
